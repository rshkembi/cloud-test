/**
 * Copyright © 2021 Scommerce Mage. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    config: {
        mixins: {
            'Magento_Catalog/js/catalog-add-to-cart': {
                'Scommerce_TrackingBase/js/add-to-cart-mixin': true
            },
            'Magento_Checkout/js/sidebar': {
                'Scommerce_TrackingBase/js/sidebar-mixin': true
            },
        }
    },
    map: {
        '*': {
			scTrackingData: 'Scommerce_TrackingBase/js/tracking-data',
            jqueryViewport: 'Scommerce_TrackingBase/js/inviewport_jquery'
        }
    }
};
