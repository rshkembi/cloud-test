/**
 * Copyright © 2021 Scommerce Mage. All rights reserved.
 * See COPYING.txt for license details.
 */
define([
    'jquery',
    'mage/translate',
	'mage/url',
    'scTrackingData'
], function($, $t, url, Tracking) {
    "use strict";

    let tracking = Tracking();
    let scUpdating = false, scClicked = false;

    function _gaAddToCart($) {
        if (scClicked === false) return;
        if (scUpdating === true) return;
        scUpdating = true;
        $.ajax({
            url: url.build('sctracking/index/addtocart'),
            type: 'get',
            dataType: 'json',
            success: function(product) {
                if (product == null) return;
                for (let i = 0; i < product.length; i++) {
                    product[i].list = tracking.getProductImpression(product[i].allSkus);
                }
                tracking.setAddToCart(product);
                $.ajax({
                    url: url.build('sctracking/index/unsaddtocart'),
                    type: 'POST',
                    data: {product},
                    success: function(response) { }
                });
            }
        }).always(function() {
            scUpdating = false;
            scClicked = false;
        });
    }

    $(document).on('ajax:addToCart', function (e, data) {
        scClicked = true;
        _gaAddToCart($);
    });

    return function (widget) {
        $.widget('mage.catalogAddToCart', widget, {

        });
        return $.mage.catalogAddToCart;
    };
});
